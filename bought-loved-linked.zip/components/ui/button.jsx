import React from "react";

const cx = (...cls) => cls.filter(Boolean).join(" ");

export function Button({ className = "", variant, size, ...props }) {
  const variants = {
    default: "bg-slate-900 text-white hover:bg-slate-800",
    outline: "border border-slate-300 dark:border-slate-700 hover:bg-slate-100/60 dark:hover:bg-slate-800/60",
    ghost: "hover:bg-slate-100/60 dark:hover:bg-slate-800/60",
  };
  const sizes = {
    default: "px-4 py-2 rounded-xl",
    sm: "px-3 py-1.5 rounded-lg text-sm",
    icon: "h-9 w-9 inline-flex items-center justify-center rounded-xl",
  };
  return <button className={cx("transition", variants[variant] ?? variants.default, sizes[size] ?? sizes.default, className)} {...props} />;
}

export default Button;
