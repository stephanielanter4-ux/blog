import React from "react";
export function Card({ className = "", ...props }) {
  return <div className={`border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 ${className}`} {...props} />;
}
export function CardContent({ className = "", ...props }) {
  return <div className={className} {...props} />;
}
