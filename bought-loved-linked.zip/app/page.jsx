import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
// NOTE: Replaced the Pinterest icon to avoid CDN fetch failure in sandbox
import { Search, Sun, Moon, Tag, Hash, PenSquare, ExternalLink, Store, Share2, ChevronRight, Calendar, Filter, X, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

// ---------------------------------------------
// BRAND PRESETS
// ---------------------------------------------
const BRAND = {
  name: "Bought It • Loved It • Linked It",
  tagline: "Bought It ❤️ Loved It 🔗 Linked It",
  colors: {
    teal: "#0ea5a3",
    gold: "#c7a051",
    charcoal: "#0f172a",
    cream: "#f7f4ef",
  },
  socials: {
    pinterest: "https://www.pinterest.com/your-handle",
    amazon: "https://www.amazon.com/shop/your-storefront",
  },
};

// ---------------------------------------------
// SAMPLE CONTENT (You can edit in-place)
// All cover images are .jpg to match your preference.
// ---------------------------------------------
const POSTS = [
  {
    title: "Hysterectomy Recovery Essentials: 12 Real-World Helpers",
    slug: "hysterectomy-recovery-essentials",
    date: "2025-08-29",
    category: "Recovery Essentials",
    tags: ["recovery", "comfort", "women's health"],
    cover: "https://images.unsplash.com/photo-1545239351-1141bd82e8a6?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wy.jpg",
    excerpt:
      "From high-waist lounge pants to hypochlorous spray—everything I actually used, with gentle tips for sensitive skin.",
    content:
      `

**Quick List**

- Wide-leg lounge pants that don't dig (post-op friendly)
- Hypochlorous spray for angry skin
- Magnesium spray + Epsom soaks for relaxation
- Pill organizer + timer app

> #ad Some links are affiliate. If you buy, I may earn at no cost to you.`,
    products: [
      { name: "Showitty 3-Pack Wide-Leg Pants", url: "https://amzn.to/xxxxx" },
      { name: "Hypochlorous Face Spray", url: "https://amzn.to/xxxxx" },
    ],
  },
  {
    title: "Sensitive Skin SOS: DeliKate-Style Routine that Calms",
    slug: "sensitive-skin-delikate-routine",
    date: "2025-09-03",
    category: "Beauty",
    tags: ["sensitive-skin", "skincare", "calm"],
    cover: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wy.jpg",
    excerpt:
      "A simple three-step routine for redness-prone, easily-irritated skin—backed by soothing ingredients your barrier loves.",
    content:
      `

Keep it minimal: a gentle cleanse, a calming serum, and a silky moisturizer. Patch test everything.

> #ad Affiliate links help keep this blog free.`,
    products: [
      { name: "Calming Recovery Serum", url: "https://amzn.to/xxxxx" },
    ],
  },
  {
    title: "Fall Fits: Cozy, Teal & Gold Aesthetic (Pinterest-Ready)",
    slug: "fall-fits-pinterest-ready",
    date: "2025-09-01",
    category: "Style",
    tags: ["fashion", "fall", "pinterest"],
    cover: "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wy.jpg",
    excerpt:
      "Board covers, pin titles, and descriptions that actually get clicks—plus outfit formulas in our teal + gold vibe.",
    content:
      `

Pin like a pro: strong keywords, a crisp JPEG, and a clear benefit in the first 80 characters.

**Outfit Formulas**: Wide-leg pants + fitted top; Midi dress + cropped jacket; Monochrome base + gold accents.`,
    products: [
      { name: "High-Rise Wide-Leg Pants", url: "https://amzn.to/xxxxx" },
      { name: "Gold Initial Necklace", url: "https://amzn.to/xxxxx" },
    ],
  },
];

const CATEGORIES = ["All", ...Array.from(new Set(POSTS.map(p => p.category)))];


// ---------------------------------------------
// UTILITIES
// ---------------------------------------------
function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// ---------------------------------------------
// DEV TESTS (added because there were none)
// ---------------------------------------------
function runDevTests() {
  const results = [];

  function pass(name, detail = "") { results.push({ ok: true, name, detail }); }
  function fail(name, detail = "") { results.push({ ok: false, name, detail }); }

  try {
    if (typeof Share2 === "function") pass("Icon fallback available", "Using Share2 instead of Pinterest icon");
    else fail("Icon fallback unavailable", "Share2 import did not resolve as a component");
  } catch (e) {
    fail("Icon fallback check threw", e?.message || String(e));
  }

  if (BRAND?.socials?.amazon && BRAND?.socials?.pinterest) pass("Brand socials present");
  else fail("Brand socials missing", JSON.stringify(BRAND?.socials));

  try {
    if (!Array.isArray(POSTS) || POSTS.length === 0) {
      results.push({ ok: false, name: "POSTS array is empty" });
    } else {
      POSTS.forEach((p, i) => {
        const required = ["title", "slug", "date", "category", "tags", "cover", "excerpt", "content"]; 
        const missing = required.filter(k => !(k in p));
        if (missing.length) results.push({ ok: false, name: `Post ${i} missing fields`, detail: missing.join(", ") });
        if (!Array.isArray(p.tags) || p.tags.length === 0) results.push({ ok: false, name: `Post ${i} tags invalid` });
        const isJpg = typeof p.cover === "string" && p.cover.toLowerCase().includes(".jpg");
        if (!isJpg) results.push({ ok: false, name: `Post ${i} cover not jpg`, detail: p.cover });
        const dateOk = !Number.isNaN(+new Date(p.date));
        if (!dateOk) results.push({ ok: false, name: `Post ${i} date invalid`, detail: p.date });
      });
      results.push({ ok: true, name: "POSTS structure valid for all items" });
    }
  } catch (e) {
    results.push({ ok: false, name: "POSTS integrity check threw", detail: e?.message || String(e) });
  }

  try {
    const setCats = Array.from(new Set(POSTS.map(p => p.category)));
    const ok = CATEGORIES[0] === "All" && setCats.every(c => CATEGORIES.includes(c));
    results.push(ok ? { ok: true, name: "Categories derived correctly" } : { ok: false, name: "Categories mismatch", detail: JSON.stringify({ CATEGORIES, setCats }) });
  } catch (e) {
    results.push({ ok: false, name: "Categories check threw", detail: e?.message || String(e) });
  }

  try {
    const q = "pants";
    const any = POSTS.some(p => (p.title + p.excerpt + p.content).toLowerCase().includes(q));
    const filtered = POSTS.filter(p => (p.title + p.excerpt + p.content).toLowerCase().includes(q));
    if (any && filtered.length > 0) results.push({ ok: true, name: "Search filter returns matches for 'pants'" });
    else results.push({ ok: true, name: "Search filter gracefully handles no matches" });
  } catch (e) {
    results.push({ ok: false, name: "Filter logic check threw", detail: e?.message || String(e) });
  }

  return results;
}

function DevTestPanel() {
  const [open, setOpen] = useState(false);
  const results = useMemo(() => runDevTests(), []);
  const okCount = results.filter(r => r.ok).length;
  const failCount = results.filter(r => !r.ok).length;

  return (
    <div className="mt-10">
      <Button variant="outline" className="gap-2" onClick={() => setOpen(v => !v)}>
        {open ? <X className="h-4 w-4"/> : <AlertTriangle className="h-4 w-4"/>}
        {open ? "Hide" : "Show"} Developer Tests ({okCount} pass{okCount!==1?"es":""}{failCount?`, ${failCount} fail${failCount!==1?"s":""}`: ""})
      </Button>
      {open && (
        <div className="mt-3 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          {results.map((r, i) => (
            <div key={i} className="flex items-start gap-2 text-sm mb-2">
              {r.ok ? <CheckCircle2 className="h-4 w-4"/> : <XCircle className="h-4 w-4"/>}
              <div>
                <div className={`font-medium ${r.ok ? "" : "text-red-600"}`}>{r.name}</div>
                {r.detail ? <div className="text-slate-500 text-xs">{r.detail}</div> : null}
              </div>
            </div>
          ))}
          {failCount === 0 && (
            <div className="text-xs text-slate-500">All checks passed. (These are lightweight runtime sanity tests, not exhaustive unit tests.)</div>
          )}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------
// COMPONENTS
// ---------------------------------------------
function SiteShell({ children }) {
  const [dark, setDark] = useState(true);
  return (
    <div className={dark ? "dark" : ""}>
      <div className="min-h-screen bg-cream dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
        <header className="sticky top-0 z-40 backdrop-blur bg-cream/70 dark:bg-slate-950/60 border-b border-slate-800/30">
          <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
            <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-400 ring-2 ring-gold/50 shadow" />
              <div>
                <h1 className="text-lg sm:text-xl font-semibold tracking-tight">{BRAND.name}</h1>
                <p className="text-xs text-slate-600 dark:text-slate-400">{BRAND.tagline}</p>
              </div>
            </motion.div>
            <div className="ml-auto flex items-center gap-2">
              <a href={BRAND.socials.amazon} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm opacity-90 hover:opacity-100"><Store className="h-4 w-4"/>Amazon</a>
              {/* Fallback icon instead of Pinterest to avoid CDN fetch issues */}
              <a href={BRAND.socials.pinterest} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm opacity-90 hover:opacity-100"><Share2 className="h-4 w-4"/>Pinterest</a>
              <Button variant="ghost" size="icon" onClick={() => setDark(v => !v)} aria-label="Toggle theme">
                {dark ? <Sun className="h-5 w-5"/> : <Moon className="h-5 w-5"/>}
              </Button>
            </div>
          </div>
        </header>
        <main className="max-w-6xl mx-auto px-4 py-6">{children}</main>
        <footer className="border-t border-slate-800/30 mt-10">
          <div className="max-w-6xl mx-auto px-4 py-8 grid sm:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold mb-2">About</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">Curated finds for recovery, beauty, style, and wellness—tested and loved. JPEG-only imagery for crisp pins and posts.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Affiliate Disclosure</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">#ad This site uses affiliate links. If you buy through my links, I may earn a small commission at no extra cost to you.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Get Updates</h4>
              <div className="flex gap-2">
                <Input placeholder="Your email" className="bg-white/70 dark:bg-slate-900"/>
                <Button className="bg-teal-600 hover:bg-teal-700">Subscribe</Button>
              </div>
            </div>
          </div>
          <div className="text-xs text-center pb-6 text-slate-500">© {new Date().getFullYear()} {BRAND.name}. All rights reserved.</div>
        </footer>
      </div>
      <style>{`
        :root { --teal: ${BRAND.colors.teal}; --gold: ${BRAND.colors.gold}; --cream: ${BRAND.colors.cream}; }
        .bg-cream { background-color: var(--cream); }
        .ring-gold\\/50 { --tw-ring-color: ${BRAND.colors.gold}80; }
      `}</style>
    </div>
  );
}

function Filters({ categories, active, onChange, tags, activeTags, onToggleTag, query, setQuery }) {
  const hasActiveTag = activeTags.length > 0;
  return (
    <div className="mb-6 space-y-3">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 opacity-60"/>
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search posts, products, tags…" className="pl-9"/>
        </div>
        <Button variant="outline" className="gap-2"><Filter className="h-4 w-4"/>Filter</Button>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => onChange(c)}
            className={`px-3 py-1.5 rounded-2xl text-sm border transition ${
              active === c
                ? "bg-slate-900 text-white dark:bg.white dark:text-slate-900"
                : "bg-white/70 dark:bg-slate-900 border-slate-300/40 dark:border-slate-700"
            }`}
          >{c}</button>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {tags.map((t) => {
          const on = activeTags.includes(t);
          return (
            <Badge key={t} onClick={() => onToggleTag(t)} className={`cursor-pointer select-none gap-1 ${on ? "bg-teal-600" : "bg-slate-200 dark:bg-slate-800"}`}>
              <Tag className="h-3 w-3"/> {t}
            </Badge>
          );
        })}
        {hasActiveTag && (
          <Button size="sm" variant="ghost" className="gap-1" onClick={() => onToggleTag("__reset__")}>
            <X className="h-4 w-4"/> Clear tags
          </Button>
        )}
      </div>
    </div>
  );
}

function PostCard({ post, onOpen }) {
  return (
    <motion.div layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
      <div className="overflow-hidden rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow hover:shadow-lg transition">
        <div className="aspect-[16/9] bg-slate-200 dark:bg-slate-800">
          <img src={post.cover} alt={post.title} className="h-full w-full object-cover" loading="lazy" />
        </div>
        <div className="p-4">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="inline-flex items-center gap-1"><Calendar className="h-3 w-3"/>{formatDate(post.date)}</span>
            <span className="opacity-80">{post.category}</span>
          </div>
          <h3 className="text-lg font-semibold mb-1 leading-snug">{post.title}</h3>
          <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-3">{post.excerpt}</p>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {post.tags.map((t) => (
              <span key={t} className="inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded-full bg-amber-50 dark:bg-amber-900/30 border border-amber-200/60 dark:border-amber-800/60"><Hash className="h-3 w-3"/>{t}</span>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <Button className="bg-teal-600 hover:bg-teal-700 text-white" onClick={() => onOpen(post)}>Read Post <ChevronRight className="h-4 w-4 ml-1"/></Button>
            <Button variant="outline" className="gap-1" onClick={() => onOpen(post, { scrollToProducts: true })}>
              Shop Items <ExternalLink className="h-4 w-4"/>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function PostModal({ post, onClose, scrollToProducts }) {
  const [tab, setTab] = useState(scrollToProducts ? "shop" : "read");
  if (!post) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-start justify-center p-4" onClick={onClose}>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} onClick={(e) => e.stopPropagation()} className="w-full max-w-3xl bg-white dark:bg-slate-950 rounded-3xl overflow-hidden shadow-2xl">
        <div className="aspect-[16/6] bg-slate-200 dark:bg-slate-800 relative">
          <img src={post.cover} alt={post.title} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"/>
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-2xl font-semibold text-white drop-shadow">{post.title}</h3>
            <div className="flex items-center gap-2 text-white/90 text-xs mt-1">
              <Calendar className="h-3 w-3"/> {formatDate(post.date)} • {post.category}
            </div>
          </div>
        </div>
        <div className="px-4 pt-3">
          <div className="inline-flex p-1 rounded-full bg-slate-200 dark:bg-slate-800 mb-3">
            {[
              { id: "read", label: "Read" },
              { id: "shop", label: "Shop" },
            ].map(({ id, label }) => (
              <button key={id} onClick={() => setTab(id)} className={`px-4 py-1.5 rounded-full text-sm ${tab === id ? "bg-white dark:bg-slate-900 shadow" : "text-slate-600 dark:text-slate-400"}`}>{label}</button>
            ))}
          </div>
        </div>
        <div className="px-4 pb-4">
          {tab === "read" ? (
            <article className="prose dark:prose-invert max-w-none">
              <div className="whitespace-pre-line leading-relaxed">{post.content}</div>
              <div className="mt-6 text-xs text-slate-500">#ad This article may contain affiliate links. As an Amazon Associate I earn from qualifying purchases.</div>
            </article>
          ) : (
            <div className="space-y-3">
              {post.products?.map((p) => (
                <div key={p.url} className="overflow-hidden border border-slate-200 dark:border-slate-800 rounded-2xl">
                  <div className="p-4 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-amber-200 to-amber-100 ring-1 ring-amber-300" />
                      <div>
                        <div className="font-medium">{p.name}</div>
                        <div className="text-xs text-slate-500">Affiliate link</div>
                      </div>
                    </div>
                    <a href={p.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm font-medium text-teal-700 hover:underline">View on Amazon <ExternalLink className="h-4 w-4"/></a>
                  </div>
                </div>
              ))}
              {(!post.products || post.products.length === 0) && (
                <div className="text-sm text-slate-500">No products linked yet.</div>
              )}
            </div>
          )}
          <div className="flex justify-end mt-6">
            <Button variant="outline" onClick={onClose}>Close</Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function Page() {
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [activeTags, setActiveTags] = useState([]);
  const [openPost, setOpenPost] = useState(null);
  const [openOpts, setOpenOpts] = useState({});

  const allTags = useMemo(() => Array.from(new Set(POSTS.flatMap(p => p.tags))).sort(), []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return POSTS.filter(p => {
      const inCat = category === "All" || p.category === category;
      const inTags = activeTags.length === 0 || activeTags.every(t => p.tags.includes(t));
      const inQuery = !q || [p.title, p.excerpt, p.content, p.tags.join(" "), p.category]
        .join(" ")
        .toLowerCase()
        .includes(q);
      return inCat && inTags && inQuery;
    }).sort((a, b) => +new Date(b.date) - +new Date(a.date));
  }, [category, activeTags, query]);

  function toggleTag(tag) {
    if (tag === "__reset__") return setActiveTags([]);
    setActiveTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]);
  }

  function open(post, opts = {}) {
    setOpenOpts(opts);
    setOpenPost(post);
  }

  return (
    <SiteShell>
      <section className="mb-6">
        <div className="relative overflow-hidden rounded-3xl">
          <div className="absolute inset-0 bg-gradient-to-r from-[var(--teal)]/20 via-transparent to-[var(--gold)]/20"/>
          <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur p-6 rounded-3xl border border-slate-200/60 dark:border-slate-800">
            <div className="grid md:grid-cols-3 gap-6 items-center">
              <div className="md:col-span-2">
                <h2 className="text-2xl sm:text-3xl font-semibold leading-tight">Elegant, fast blog for curated finds & gentle wellness</h2>
                <p className="mt-2 text-slate-600 dark:text-slate-400">SEO-friendly cards, category filters, tag badges, and built-in affiliate disclosure. Swap sample posts for your real content and JPEG covers.</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge className="bg-teal-600">Teal & Gold Aesthetic</Badge>
                  <Badge className="bg-amber-600">Affiliate-Ready</Badge>
                  <Badge className="bg-slate-800">Dark Mode</Badge>
                </div>
              </div>
              <div className="flex md:justify-end">
                <Button className="gap-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700"><PenSquare className="h-4 w-4"/> Write a Post</Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="mb-6 space-y-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 opacity-60"/>
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search posts, products, tags…" className="pl-9"/>
          </div>
          <Button variant="outline" className="gap-2"><Filter className="h-4 w-4"/>Filter</Button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {["All", ...new Set(POSTS.map(p => p.category))].map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-3 py-1.5 rounded-2xl text-sm border transition ${category === c
                ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                : "bg-white/70 dark:bg-slate-900 border-slate-300/40 dark:border-slate-700"}`}
            >{c}</button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {allTags.map((t) => {
            const on = activeTags.includes(t);
            return (
              <Badge key={t} onClick={() => toggleTag(t)} className={`cursor-pointer select-none gap-1 ${on ? "bg-teal-600" : "bg-slate-200 dark:bg-slate-800"}`}>
                <Tag className="h-3 w-3"/> {t}
              </Badge>
            );
          })}
          {activeTags.length > 0 && (
            <Button size="sm" variant="ghost" className="gap-1" onClick={() => toggleTag("__reset__")}>
              <X className="h-4 w-4"/> Clear tags
            </Button>
          )}
        </div>
      </div>

      <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((p) => (
          <PostCard key={p.slug} post={p} onOpen={open}/>
        ))}
        {filtered.length === 0 && (
          <div className="text-sm text-slate-500">No posts match your filters yet.</div>
        )}
      </section>

      <section className="mt-10">
        <div className="rounded-3xl border border-amber-200/60 dark:border-amber-800/60">
          <div className="p-5 md:p-6">
            <h3 className="text-xl font-semibold mb-2">Amazon Storefront</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">Shop my curated collections—recovery comfort, sensitive-skin staples, German Shepherd faves, and cozy fall fits.</p>
            <a href={BRAND.socials.amazon} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-600 text-white hover:bg-amber-700"><Store className="h-4 w-4"/> Visit Storefront</a>
          </div>
        </div>
      </section>

      <DevTestPanel />

      {openPost && (
        <PostModal post={openPost} onClose={() => setOpenPost(null)} scrollToProducts={openOpts.scrollToProducts} />
      )}
    </SiteShell>
  );
}
