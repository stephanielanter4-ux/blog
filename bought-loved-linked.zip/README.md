# Bought It • Loved It • Linked It — Blog

This is a ready-to-upload Next.js project of your blog. No command-line needed.

## Deploy (no-code, easiest)
1. Go to https://vercel.com → Sign up (free).
2. Click **New Project** → **Import** → choose **Manual** or **Drag & Drop**.
3. Upload this entire folder as a **.zip** (see file provided).
4. Vercel builds and gives you a live URL like `https://your-site.vercel.app`.

## Edit content
- Open `app/page.jsx` and change the `POSTS` array and `BRAND.socials` to your real links.
- Use `.jpg` images for covers to match your preference.

## Optional (run locally)
If you want to see it on your computer:
```bash
npm install
npm run dev
# then open http://localhost:3000
```
